/* ═══════════════════════════════════════════════
   🤖 بوت التداول الذكي - JavaScript
   يعمل مع Binance API (Testnet مجاني)
   ═══════════════════════════════════════════════ */

// ═══════════════════════════════════════════════
// المتغيرات العامة
// ═══════════════════════════════════════════════

let config = {
    apiKey: '',
    apiSecret: '',
    testnet: true,
    symbol: 'BTC/USDT',
    timeframe: '15m',
    rsiPeriod: 14,
    rsiOverbought: 70,
    rsiOversold: 30,
    tradeAmount: 11,
    stopLoss: 2,
    takeProfit: 4,
    autoTrade: false,
    alertSignals: true,
    alertTrades: true
};

let appState = {
    connected: false,
    currentPrice: 0,
    priceChange: 0,
    rsi: 50,
    volume: 0,
    trend: 'neutral',
    support: 0,
    resistance: 0,
    position: null,
    entryPrice: 0,
    candles: [],
    signals: [],
    trades: [],
    history: [],
    chart: null,
    miniChart: null,
    updateInterval: null,
    lastSignal: null
};

// ═══════════════════════════════════════════════
// تهيئة التطبيق
// ═══════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', function() {
    loadConfig();

    if (config.apiKey && config.apiSecret) {
        showScreen('main');
        initApp();
    } else {
        showScreen('setup');
    }

    setTimeout(() => {
        document.getElementById('loading-screen').style.display = 'none';
    }, 1000);
});

function showScreen(screen) {
    document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden'));

    if (screen === 'setup') {
        document.getElementById('setup-screen').classList.remove('hidden');
    } else if (screen === 'main') {
        document.getElementById('main-screen').classList.remove('hidden');
    }
}

function loadConfig() {
    const saved = localStorage.getItem('tradingBotConfig');
    if (saved) {
        config = { ...config, ...JSON.parse(saved) };
    }
}

function saveConfig() {
    localStorage.setItem('tradingBotConfig', JSON.stringify(config));
}

// ═══════════════════════════════════════════════
// إعدادات API
// ═══════════════════════════════════════════════

function saveSettings() {
    const apiKey = document.getElementById('api-key').value.trim();
    const apiSecret = document.getElementById('api-secret').value.trim();
    const testnet = document.getElementById('testnet-toggle').checked;

    if (!apiKey || !apiSecret) {
        showNotification('❌ الرجاء إدخال مفاتيح API', 'error');
        return;
    }

    config.apiKey = apiKey;
    config.apiSecret = apiSecret;
    config.testnet = testnet;

    saveConfig();
    showScreen('main');
    initApp();
}

function disconnect() {
    if (appState.updateInterval) {
        clearInterval(appState.updateInterval);
    }

    config.apiKey = '';
    config.apiSecret = '';
    saveConfig();

    localStorage.removeItem('tradingBotConfig');
    showScreen('setup');
    showNotification('🔌 تم قطع الاتصال', 'warning');
}

// ═══════════════════════════════════════════════
// تهيئة التطبيق الرئيسي
// ═══════════════════════════════════════════════

function initApp() {
    document.getElementById('setting-symbol').value = config.symbol;
    document.getElementById('setting-timeframe').value = config.timeframe;
    document.getElementById('setting-rsi-period').value = config.rsiPeriod;
    document.getElementById('setting-rsi-overbought').value = config.rsiOverbought;
    document.getElementById('setting-rsi-oversold').value = config.rsiOversold;
    document.getElementById('setting-amount').value = config.tradeAmount;
    document.getElementById('setting-sl').value = config.stopLoss;
    document.getElementById('setting-tp').value = config.takeProfit;
    document.getElementById('alert-signals').checked = config.alertSignals;
    document.getElementById('alert-trades').checked = config.alertTrades;

    initCharts();
    fetchData();
    appState.updateInterval = setInterval(fetchData, 15000);

    showNotification('✅ تم الاتصال بنجاح!', 'success');
}

// ═══════════════════════════════════════════════
// جلب بيانات Binance
// ═══════════════════════════════════════════════

async function fetchData() {
    try {
        const candles = await fetchCandles();
        if (candles && candles.length > 0) {
            appState.candles = candles;
            processData(candles);
            updateUI();
            updateCharts();
            checkSignals();
            checkAutoTrade();
        }

        const ticker = await fetchTicker();
        if (ticker) {
            appState.currentPrice = parseFloat(ticker.lastPrice);
            appState.priceChange = parseFloat(ticker.priceChangePercent);
        }

        appState.connected = true;
        updateConnectionStatus(true);

    } catch (error) {
        console.error('Error fetching data:', error);
        appState.connected = false;
        updateConnectionStatus(false);
    }
}

async function fetchCandles() {
    const symbol = config.symbol.replace('/', '');
    const interval = config.timeframe;
    const limit = 100;

    const baseUrl = config.testnet 
        ? 'https://testnet.binance.vision/api'
        : 'https://api.binance.com/api';

    const url = `${baseUrl}/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;

    const response = await fetch(url);
    const data = await response.json();

    return data.map(candle => ({
        timestamp: candle[0],
        open: parseFloat(candle[1]),
        high: parseFloat(candle[2]),
        low: parseFloat(candle[3]),
        close: parseFloat(candle[4]),
        volume: parseFloat(candle[5])
    }));
}

async function fetchTicker() {
    const symbol = config.symbol.replace('/', '');

    const baseUrl = config.testnet 
        ? 'https://testnet.binance.vision/api'
        : 'https://api.binance.com/api';

    const url = `${baseUrl}/v3/ticker/24hr?symbol=${symbol}`;

    const response = await fetch(url);
    return await response.json();
}

// ═══════════════════════════════════════════════
// معالجة البيانات والمؤشرات
// ═══════════════════════════════════════════════

function processData(candles) {
    const closes = candles.map(c => c.close);
    const volumes = candles.map(c => c.volume);

    appState.rsi = calculateRSI(closes, config.rsiPeriod);

    const avgVolume = volumes.slice(-20).reduce((a, b) => a + b, 0) / 20;
    const currentVolume = volumes[volumes.length - 1];
    appState.volume = (currentVolume / avgVolume) * 100;

    appState.trend = calculateTrend(candles);

    const levels = calculateSupportResistance(candles);
    appState.support = levels.support;
    appState.resistance = levels.resistance;
}

function calculateRSI(closes, period) {
    if (closes.length < period + 1) return 50;

    let gains = 0;
    let losses = 0;

    for (let i = 1; i <= period; i++) {
        const change = closes[i] - closes[i - 1];
        if (change > 0) gains += change;
        else losses -= change;
    }

    let avgGain = gains / period;
    let avgLoss = losses / period;

    for (let i = period + 1; i < closes.length; i++) {
        const change = closes[i] - closes[i - 1];
        if (change > 0) {
            avgGain = (avgGain * (period - 1) + change) / period;
            avgLoss = (avgLoss * (period - 1)) / period;
        } else {
            avgGain = (avgGain * (period - 1)) / period;
            avgLoss = (avgLoss * (period - 1) - change) / period;
        }
    }

    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
}

function calculateTrend(candles) {
    const period = 20;
    if (candles.length < period) return 'neutral';

    const recent = candles.slice(-period);
    const sma = recent.reduce((sum, c) => sum + c.close, 0) / period;
    const currentPrice = candles[candles.length - 1].close;

    const ema12 = calculateEMA(candles.map(c => c.close), 12);
    const ema26 = calculateEMA(candles.map(c => c.close), 26);

    if (ema12 > ema26 && currentPrice > sma) return 'bullish';
    if (ema12 < ema26 && currentPrice < sma) return 'bearish';
    return 'neutral';
}

function calculateEMA(data, period) {
    const k = 2 / (period + 1);
    let ema = data[0];
    for (let i = 1; i < data.length; i++) {
        ema = data[i] * k + ema * (1 - k);
    }
    return ema;
}

function calculateSupportResistance(candles) {
    const period = 20;
    const recent = candles.slice(-period);
    const highs = recent.map(c => c.high);
    const lows = recent.map(c => c.low);

    const resistance = Math.max(...highs);
    const support = Math.min(...lows);

    return { support, resistance };
}

// ═══════════════════════════════════════════════
// التحقق من الإشارات
// ═══════════════════════════════════════════════

function checkSignals() {
    const rsi = appState.rsi;
    const volume = appState.volume;
    const trend = appState.trend;
    const price = appState.currentPrice;
    const support = appState.support;
    const resistance = appState.resistance;

    let signal = null;
    let details = [];

    const rsiBuy = rsi < config.rsiOversold;
    const rsiSell = rsi > config.rsiOverbought;
    const volumeStrong = volume > 120;
    const trendUp = trend === 'bullish';
    const trendDown = trend === 'bearish';
    const nearSupport = price <= support * 1.02;
    const nearResistance = price >= resistance * 0.98;

    if (rsiBuy && volumeStrong && trendUp && nearSupport) {
        signal = 'BUY';
        details = [
            `RSI: ${rsi.toFixed(1)} (تشبع بيعي)`,
            `Volume: ${volume.toFixed(0)}% (قوي)`,
            `الاتجاه: صاعد`,
            `قرب الدعم: ${support.toFixed(2)}`
        ];
    } else if (rsiSell && volumeStrong && trendDown && nearResistance) {
        signal = 'SELL';
        details = [
            `RSI: ${rsi.toFixed(1)} (تشبع شرائي)`,
            `Volume: ${volume.toFixed(0)}% (قوي)`,
            `الاتجاه: هابط`,
            `قرب المقاومة: ${resistance.toFixed(2)}`
        ];
    } else {
        let reasons = [];
        if (rsiBuy) reasons.push('RSI تشبع بيعي');
        else if (rsiSell) reasons.push('RSI تشبع شرائي');
        else reasons.push('RSI متعادل');

        if (volumeStrong) reasons.push('Volume قوي');
        else reasons.push('Volume ضعيف');

        if (trendUp) reasons.push('الاتجاه صاعد');
        else if (trendDown) reasons.push('الاتجاه هابط');
        else reasons.push('الاتجاه متعادل');

        details = reasons;
    }

    updateSignalUI(signal, details);

    if (signal && signal !== appState.lastSignal) {
        appState.lastSignal = signal;
        addSignal(signal, details);

        if (config.alertSignals) {
            showNotification(`📡 إشارة ${signal === 'BUY' ? 'شراء' : 'بيع'}!`, 'warning');
        }
    }

    appState.currentSignal = signal;
}

function updateSignalUI(signal, details) {
    const signalMain = document.getElementById('signal-main');
    const signalDetails = document.getElementById('signal-details');
    const signalTime = document.getElementById('signal-time');
    const btnBuy = document.getElementById('btn-buy');
    const btnSell = document.getElementById('btn-sell');

    signalTime.textContent = new Date().toLocaleTimeString('ar-SA');

    if (signal === 'BUY') {
        signalMain.textContent = '🟢 إشارة شراء قوية!';
        signalMain.className = 'signal-main buy';
        signalDetails.innerHTML = details.join('<br>');
        btnBuy.disabled = false;
        btnSell.disabled = true;
    } else if (signal === 'SELL') {
        signalMain.textContent = '🔴 إشارة بيع قوية!';
        signalMain.className = 'signal-main sell';
        signalDetails.innerHTML = details.join('<br>');
        btnBuy.disabled = true;
        btnSell.disabled = false;
    } else {
        signalMain.textContent = '⏳ لا توجد إشارة واضحة';
        signalMain.className = 'signal-main wait';
        signalDetails.innerHTML = details.join('<br>');
        btnBuy.disabled = true;
        btnSell.disabled = true;
    }
}

function addSignal(type, details) {
    const signal = {
        type,
        details,
        time: new Date().toISOString(),
        price: appState.currentPrice
    };

    appState.signals.unshift(signal);
    if (appState.signals.length > 50) appState.signals.pop();

    updateSignalsList();
}

function updateSignalsList() {
    const list = document.getElementById('signals-list');

    if (appState.signals.length === 0) {
        list.innerHTML = `
            <div class="empty-state">
                <span>📭</span>
                <p>لا توجد إشارات بعد</p>
            </div>
        `;
        return;
    }

    list.innerHTML = appState.signals.map(s => `
        <div class="signal-item ${s.type.toLowerCase()}">
            <div>
                <strong>${s.type === 'BUY' ? '🟢 شراء' : '🔴 بيع'}</strong>
                <div style="font-size: 0.8rem; color: var(--text-secondary); margin-top: 4px;">
                    ${s.details[0]}
                </div>
            </div>
            <div style="text-align: left;">
                <div style="font-weight: 600;">${s.price.toFixed(2)}</div>
                <div style="font-size: 0.75rem; color: var(--text-secondary);">
                    ${new Date(s.time).toLocaleTimeString('ar-SA')}
                </div>
            </div>
        </div>
    `).join('');
}

// ═══════════════════════════════════════════════
// التداول التلقائي
// ═══════════════════════════════════════════════

function toggleAutoTrade() {
    const toggle = document.getElementById('auto-trade-toggle');
    config.autoTrade = toggle.checked;
    saveConfig();

    const status = document.getElementById('auto-trade-status');
    if (config.autoTrade) {
        status.textContent = '🟢 نشط - يفتح صفقات تلقائية';
        status.classList.add('active');
        showNotification('🤖 التداول التلقائي مفعل!', 'success');
    } else {
        status.textContent = '⏸️ معطل';
        status.classList.remove('active');
        showNotification('⏸️ التداول التلقائي معطل', 'warning');
    }
}

function checkAutoTrade() {
    if (!config.autoTrade) return;
    if (!appState.currentSignal) return;

    if (appState.currentSignal === 'BUY' && !appState.position) {
        manualBuy();
    } else if (appState.currentSignal === 'SELL' && appState.position === 'long') {
        manualSell();
    }

    checkStopLossTakeProfit();
}

function checkStopLossTakeProfit() {
    if (!appState.position || !appState.entryPrice) return;

    const currentPrice = appState.currentPrice;
    const changePercent = ((currentPrice - appState.entryPrice) / appState.entryPrice) * 100;

    if (appState.position === 'long') {
        if (changePercent <= -config.stopLoss) {
            showNotification(`🛑 وقف الخسارة: ${changePercent.toFixed(2)}%`, 'error');
            manualSell();
        } else if (changePercent >= config.takeProfit) {
            showNotification(`🎯 جني الأرباح: ${changePercent.toFixed(2)}%`, 'success');
            manualSell();
        }
    }
}

// ═══════════════════════════════════════════════
// تنفيذ الصفقات
// ═══════════════════════════════════════════════

async function manualBuy() {
    if (appState.position) {
        showNotification('⚠️ لديك صفقة مفتوحة بالفعل', 'warning');
        return;
    }

    try {
        appState.position = 'long';
        appState.entryPrice = appState.currentPrice;

        const trade = {
            type: 'BUY',
            price: appState.currentPrice,
            amount: config.tradeAmount / appState.currentPrice,
            time: new Date().toISOString(),
            status: 'open'
        };

        appState.trades.push(trade);

        showNotification(`🟢 تم فتح صفقة شراء بسعر ${appState.currentPrice.toFixed(2)}`, 'success');

        updateTradesList();
        updateSignalUI(null, ['صفقة شراء مفتوحة - انتظر إشارة البيع']);

    } catch (error) {
        showNotification('❌ فشل فتح الصفقة: ' + error.message, 'error');
    }
}

async function manualSell() {
    if (!appState.position) {
        showNotification('⚠️ لا توجد صفقة مفتوحة', 'warning');
        return;
    }

    try {
        const exitPrice = appState.currentPrice;
        const pnlPercent = ((exitPrice - appState.entryPrice) / appState.entryPrice) * 100;
        const pnlUSDT = (exitPrice - appState.entryPrice) * (config.tradeAmount / appState.entryPrice);

        const trade = {
            type: 'SELL',
            price: exitPrice,
            amount: config.tradeAmount / appState.entryPrice,
            entryPrice: appState.entryPrice,
            pnlPercent,
            pnlUSDT,
            time: new Date().toISOString(),
            status: 'closed'
        };

        appState.history.unshift(trade);
        appState.trades = [];
        appState.position = null;
        appState.entryPrice = 0;

        const emoji = pnlPercent > 0 ? '✅' : '❌';
        showNotification(
            `${emoji} تم إغلاق الصفقة | الربح: ${pnlPercent.toFixed(2)}% (${pnlUSDT.toFixed(2)} USDT)`,
            pnlPercent > 0 ? 'success' : 'error'
        );

        updateTradesList();
        updateHistoryList();

    } catch (error) {
        showNotification('❌ فشل إغلاق الصفقة: ' + error.message, 'error');
    }
}

function updateTradesList() {
    const list = document.getElementById('trades-list');

    if (appState.trades.length === 0) {
        list.innerHTML = `
            <div class="empty-state">
                <span>💼</span>
                <p>لا توجد صفقات نشطة</p>
            </div>
        `;
        return;
    }

    list.innerHTML = appState.trades.map(t => {
        const currentPnl = appState.position === 'long' 
            ? ((appState.currentPrice - t.price) / t.price) * 100 
            : 0;

        return `
            <div class="trade-item">
                <div>
                    <strong>🟢 شراء</strong>
                    <div style="font-size: 0.8rem; color: var(--text-secondary);">
                        سعر الدخول: ${t.price.toFixed(2)}
                    </div>
                </div>
                <div style="text-align: left;">
                    <div style="color: ${currentPnl >= 0 ? 'var(--accent-green)' : 'var(--accent-red)'}; font-weight: 600;">
                        ${currentPnl >= 0 ? '+' : ''}${currentPnl.toFixed(2)}%
                    </div>
                    <div style="font-size: 0.75rem; color: var(--text-secondary);">
                        ${new Date(t.time).toLocaleTimeString('ar-SA')}
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

function updateHistoryList() {
    const list = document.getElementById('trades-history');

    if (appState.history.length === 0) {
        list.innerHTML = `
            <div class="empty-state">
                <span>📋</span>
                <p>لا توجد صفقات منفذة</p>
            </div>
        `;
        return;
    }

    list.innerHTML = appState.history.map(t => `
        <div class="trade-item">
            <div>
                <strong>${t.type === 'SELL' ? '🔴 بيع' : '🟢 شراء'}</strong>
                <div style="font-size: 0.8rem; color: var(--text-secondary);">
                    دخول: ${t.entryPrice?.toFixed(2) || '-'} | خروج: ${t.price.toFixed(2)}
                </div>
            </div>
            <div style="text-align: left;">
                <div style="color: ${t.pnlPercent >= 0 ? 'var(--accent-green)' : 'var(--accent-red)'}; font-weight: 600;">
                    ${t.pnlPercent >= 0 ? '+' : ''}${t.pnlPercent.toFixed(2)}%
                </div>
                <div style="font-size: 0.75rem; color: var(--text-secondary);">
                    ${t.pnlUSDT.toFixed(2)} USDT
                </div>
            </div>
        </div>
    `).join('');
}

// ═══════════════════════════════════════════════
// تحديث واجهة المستخدم
// ═══════════════════════════════════════════════

function updateUI() {
    document.getElementById('current-symbol').textContent = config.symbol;
    document.getElementById('current-price').textContent = '$' + appState.currentPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    const changeEl = document.getElementById('price-change');
    changeEl.textContent = (appState.priceChange >= 0 ? '+' : '') + appState.priceChange.toFixed(2) + '%';
    changeEl.className = 'change ' + (appState.priceChange >= 0 ? 'positive' : 'negative');

    const rsiEl = document.getElementById('rsi-value');
    const rsiProgress = document.getElementById('rsi-progress');
    const rsiStatus = document.getElementById('rsi-status');

    rsiEl.textContent = appState.rsi.toFixed(1);
    rsiProgress.style.width = appState.rsi + '%';

    if (appState.rsi < config.rsiOversold) {
        rsiProgress.style.background = 'var(--accent-green)';
        rsiStatus.textContent = 'تشبع بيعي';
        document.getElementById('rsi-card').style.borderColor = 'var(--accent-green)';
    } else if (appState.rsi > config.rsiOverbought) {
        rsiProgress.style.background = 'var(--accent-red)';
        rsiStatus.textContent = 'تشبع شرائي';
        document.getElementById('rsi-card').style.borderColor = 'var(--accent-red)';
    } else {
        rsiProgress.style.background = 'var(--accent-blue)';
        rsiStatus.textContent = 'متعادل';
        document.getElementById('rsi-card').style.borderColor = 'var(--border-color)';
    }

    const volEl = document.getElementById('volume-value');
    const volProgress = document.getElementById('volume-progress');
    const volStatus = document.getElementById('volume-status');

    volEl.textContent = appState.volume.toFixed(0) + '%';
    volProgress.style.width = Math.min(appState.volume, 100) + '%';

    if (appState.volume > 150) {
        volProgress.style.background = 'var(--accent-green)';
        volStatus.textContent = 'قوي جداً';
    } else if (appState.volume > 100) {
        volProgress.style.background = 'var(--accent-blue)';
        volStatus.textContent = 'جيد';
    } else {
        volProgress.style.background = 'var(--accent-red)';
        volStatus.textContent = 'ضعيف';
    }

    const trendEl = document.getElementById('trend-value');
    const trendArrow = document.getElementById('trend-arrow');
    const trendStatus = document.getElementById('trend-status');

    if (appState.trend === 'bullish') {
        trendEl.textContent = 'صاعد';
        trendEl.style.color = 'var(--accent-green)';
        trendArrow.textContent = '📈';
        trendStatus.textContent = 'EMA12 > EMA26';
    } else if (appState.trend === 'bearish') {
        trendEl.textContent = 'هابط';
        trendEl.style.color = 'var(--accent-red)';
        trendArrow.textContent = '📉';
        trendStatus.textContent = 'EMA12 < EMA26';
    } else {
        trendEl.textContent = 'متعادل';
        trendEl.style.color = 'var(--text-secondary)';
        trendArrow.textContent = '➡️';
        trendStatus.textContent = 'لا اتجاه واضح';
    }

    document.getElementById('resistance-value').textContent = '$' + appState.resistance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    document.getElementById('support-value').textContent = '$' + appState.support.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    document.getElementById('sr-current').textContent = '$' + appState.currentPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function updateConnectionStatus(connected) {
    const status = document.getElementById('connection-status');
    if (connected) {
        status.textContent = '🟢 متصل';
        status.style.background = 'rgba(0, 208, 132, 0.2)';
        status.style.color = 'var(--accent-green)';
    } else {
        status.textContent = '🔴 غير متصل';
        status.style.background = 'rgba(255, 71, 87, 0.2)';
        status.style.color = 'var(--accent-red)';
    }
}

// ═══════════════════════════════════════════════
// الرسوم البيانية
// ═══════════════════════════════════════════════

function initCharts() {
    const ctx = document.getElementById('main-chart').getContext('2d');
    appState.chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: config.symbol,
                data: [],
                borderColor: '#3498db',
                backgroundColor: 'rgba(52, 152, 219, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4,
                pointRadius: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: {
                    grid: { color: 'rgba(255,255,255,0.05)' },
                    ticks: { color: '#a0a0b0', font: { size: 10 }, maxTicksLimit: 6 }
                },
                y: {
                    grid: { color: 'rgba(255,255,255,0.05)' },
                    ticks: { color: '#a0a0b0', font: { size: 10 } }
                }
            }
        }
    });

    const miniCtx = document.getElementById('mini-chart').getContext('2d');
    appState.miniChart = new Chart(miniCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                data: [],
                borderColor: '#3498db',
                borderWidth: 2,
                pointRadius: 0,
                fill: false,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { display: false },
                y: { display: false }
            }
        }
    });
}

function updateCharts() {
    if (!appState.candles || appState.candles.length === 0) return;

    const recent = appState.candles.slice(-20);
    appState.miniChart.data.labels = recent.map((_, i) => i);
    appState.miniChart.data.datasets[0].data = recent.map(c => c.close);

    const isUp = recent[recent.length - 1].close >= recent[0].close;
    appState.miniChart.data.datasets[0].borderColor = isUp ? '#00d084' : '#ff4757';
    appState.miniChart.update('none');

    const labels = appState.candles.map(c => {
        const date = new Date(c.timestamp);
        return date.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });
    });

    appState.chart.data.labels = labels;
    appState.chart.data.datasets[0].data = appState.candles.map(c => c.close);
    appState.chart.data.datasets[0].borderColor = isUp ? '#00d084' : '#ff4757';
    appState.chart.data.datasets[0].backgroundColor = isUp ? 'rgba(0, 208, 132, 0.1)' : 'rgba(255, 71, 87, 0.1)';

    appState.chart.update('none');
}

// ═══════════════════════════════════════════════
// التنقل والقوائم
// ═══════════════════════════════════════════════

function toggleMenu() {
    document.getElementById('side-menu').classList.toggle('open');
}

function showSection(section) {
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));

    document.getElementById(section + '-section').classList.add('active');

    const navItems = document.querySelectorAll('.nav-item');
    const sectionMap = { 'dashboard': 0, 'signals': 1, 'trades': 2, 'settings': 3 };
    if (sectionMap[section] !== undefined) {
        navItems[sectionMap[section]].classList.add('active');
    }

    document.getElementById('side-menu').classList.remove('open');

    if (section === 'signals') updateSignalsList();
    if (section === 'trades') {
        updateTradesList();
        updateHistoryList();
    }
}

function showSettings() {
    showSection('settings');
}

function changeTimeframe(tf) {
    config.timeframe = tf;
    saveConfig();

    document.querySelectorAll('.timeframe-buttons button').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');

    fetchData();
    showNotification(`⏱️ تم تغيير الإطار الزمني`, 'success');
}

function saveBotSettings() {
    config.symbol = document.getElementById('setting-symbol').value;
    config.timeframe = document.getElementById('setting-timeframe').value;
    config.rsiPeriod = parseInt(document.getElementById('setting-rsi-period').value);
    config.rsiOverbought = parseInt(document.getElementById('setting-rsi-overbought').value);
    config.rsiOversold = parseInt(document.getElementById('setting-rsi-oversold').value);
    config.tradeAmount = parseFloat(document.getElementById('setting-amount').value);
    config.stopLoss = parseFloat(document.getElementById('setting-sl').value);
    config.takeProfit = parseFloat(document.getElementById('setting-tp').value);
    config.alertSignals = document.getElementById('alert-signals').checked;
    config.alertTrades = document.getElementById('alert-trades').checked;

    saveConfig();
    showNotification('💾 تم حفظ الإعدادات!', 'success');

    if (appState.updateInterval) clearInterval(appState.updateInterval);
    initApp();
}

// ═══════════════════════════════════════════════
// نظام التنبيهات
// ═══════════════════════════════════════════════

function showNotification(message, type = 'info') {
    const container = document.getElementById('notifications');

    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <span>${message}</span>
        <button class="notification-close" onclick="this.parentElement.remove()">✕</button>
    `;

    container.appendChild(notification);

    setTimeout(() => {
        if (notification.parentElement) {
            notification.style.opacity = '0';
            notification.style.transform = 'translateY(-20px)';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

// ═══════════════════════════════════════════════
// Service Worker
// ═══════════════════════════════════════════════

if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(err => {
        console.log('SW registration failed:', err);
    });
}
